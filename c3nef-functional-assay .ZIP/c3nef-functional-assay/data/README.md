# Synthetic C3NeF Assay Data

This dataset is **fully synthetic** and is provided only for portfolio/demo purposes.

## Experimental concept

The functional C3 nephritic factor (C3NeF) assay evaluates stabilization of the
alternative-pathway C3 convertase. C3NeF can prolong convertase activity, producing
a stronger residual hemolytic signal after a defined decay interval.

The synthetic dataset contains:
- 6 samples
- 3 C3NeF-negative and 3 C3NeF-positive examples
- duplicate measurements
- 5 post-convertase time points: 5, 15, 30, 45 and 60 min
- percentage hemolysis as the functional readout

**These values are not clinical or laboratory results.**
