from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import ttest_ind

def summarize_assay(df: pd.DataFrame) -> pd.DataFrame:
    """Summarize mean and SD hemolysis by sample and time."""
    return (
        df.groupby(["sample_id", "group", "time_min"])["hemolysis_percent"]
        .agg(["mean", "std"])
        .reset_index()
        .rename(columns={"mean":"mean_hemolysis", "std":"sd_hemolysis"})
    )

def calculate_auc(df: pd.DataFrame) -> pd.DataFrame:
    """Calculate trapezoidal area under the hemolysis-vs-time curve."""
    summary = summarize_assay(df)
    out = []
    for (sid, group), g in summary.groupby(["sample_id", "group"]):
        g = g.sort_values("time_min")
        auc = np.trapezoid(g["mean_hemolysis"], g["time_min"])
        residual_60 = float(g.loc[g["time_min"] == 60, "mean_hemolysis"].iloc[0])
        out.append([sid, group, auc, residual_60])
    return pd.DataFrame(out, columns=[
        "sample_id", "group", "hemolysis_auc", "residual_hemolysis_60min"
    ])

def compare_groups(df: pd.DataFrame) -> dict:
    """Compare sample-level AUC between synthetic positive and negative groups."""
    auc = calculate_auc(df)
    pos = auc.loc[auc.group == "Positive", "hemolysis_auc"]
    neg = auc.loc[auc.group == "Negative", "hemolysis_auc"]
    stat, p = ttest_ind(pos, neg, equal_var=False)
    return {
        "positive_mean_auc": float(pos.mean()),
        "negative_mean_auc": float(neg.mean()),
        "welch_t_statistic": float(stat),
        "welch_p_value": float(p),
    }
