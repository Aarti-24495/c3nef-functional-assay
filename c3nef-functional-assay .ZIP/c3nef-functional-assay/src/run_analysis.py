from pathlib import Path
import json
import pandas as pd
from analysis import calculate_auc, compare_groups
from visualization import plot_time_course, plot_auc, plot_residual

ROOT = Path(__file__).resolve().parents[1]
df = pd.read_csv(ROOT / "data" / "synthetic_c3nef_assay.csv")

auc = calculate_auc(df)
auc.to_csv(ROOT / "results" / "c3nef_activity_summary.csv", index=False)

stats = compare_groups(df)
(ROOT / "results" / "analysis_summary.json").write_text(json.dumps(stats, indent=2))

plot_time_course(df, ROOT / "results" / "figures" / "01_hemolysis_time_course.png")
plot_auc(auc, ROOT / "results" / "figures" / "02_c3nef_auc.png")
plot_residual(auc, ROOT / "results" / "figures" / "03_residual_hemolysis.png")

print("C3NeF analysis completed.")
print(auc.round(2).to_string(index=False))
print(stats)
