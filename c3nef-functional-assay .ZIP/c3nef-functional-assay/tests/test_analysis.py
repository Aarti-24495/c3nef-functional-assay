import sys
from pathlib import Path
import pandas as pd
sys.path.append(str(Path(__file__).resolve().parents[1] / "src"))
from analysis import summarize_assay, calculate_auc

ROOT = Path(__file__).resolve().parents[1]

def test_dataset_structure():
    df = pd.read_csv(ROOT / "data" / "synthetic_c3nef_assay.csv")
    assert df["sample_id"].nunique() == 6
    assert set(df["time_min"]) == {5,15,30,45,60}
    assert set(df["replicate"]) == {1,2}

def test_auc_output():
    df = pd.read_csv(ROOT / "data" / "synthetic_c3nef_assay.csv")
    auc = calculate_auc(df)
    assert len(auc) == 6
    assert (auc["hemolysis_auc"] > 0).all()
