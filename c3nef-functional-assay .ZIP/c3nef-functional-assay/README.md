# C3NeF Functional Assay Analysis

**Python-based analysis of a functional C3 nephritic factor (C3NeF) assay using synthetic hemolytic assay data.**

## Overview

C3 nephritic factor (C3NeF) is an autoantibody that can stabilize the alternative-pathway C3 convertase, prolonging complement activation. Functional hemolytic assays use this convertase-stabilizing activity to generate a measurable hemolysis signal.

This project demonstrates how to analyze **time-dependent hemolysis data** from a C3NeF functional assay, summarize residual convertase-associated activity, and quantify the overall signal using area under the curve (AUC).

> **Important:** All data in this repository are synthetic and are not patient results or real laboratory measurements.

## What this project demonstrates

- Functional complement assay data handling
- C3 convertase stabilization concept
- Time-course hemolysis analysis
- Replicate summarization
- Trapezoidal AUC calculation
- Group-level statistical comparison
- Publication-style visualization
- Reproducible Python workflow
- Basic software testing and project structure

## Assay concept

A functional C3NeF assay evaluates whether patient-derived factors can prolong the activity/stability of the alternative-pathway C3 convertase. In hemolytic formats, residual convertase activity is ultimately translated into erythrocyte lysis, which can be measured spectrophotometrically.

The analysis in this repository focuses on the **data-analysis layer**, not on providing a laboratory protocol.

## Analysis workflow

```text
Synthetic hemolysis data
        |
        v
Quality / replicate handling
        |
        v
Mean hemolysis by time point
        |
        +--------------------+
        |                    |
        v                    v
Time-course profile       Residual signal
        |                    |
        +---------+----------+
                  |
                  v
          Hemolysis AUC
                  |
                  v
      Sample/group comparison
                  |
                  v
       Figures + CSV outputs
```

## Repository structure

```text
c3nef-functional-assay/
├── data/
│   ├── synthetic_c3nef_assay.csv
│   └── README.md
├── notebooks/
│   └── 01_c3nef_functional_assay_analysis.ipynb
├── results/
│   ├── c3nef_activity_summary.csv
│   ├── analysis_summary.json
│   └── figures/
│       ├── 01_hemolysis_time_course.png
│       ├── 02_c3nef_auc.png
│       └── 03_residual_hemolysis.png
├── src/
│   ├── analysis.py
│   ├── visualization.py
│   └── run_analysis.py
├── tests/
│   └── test_analysis.py
├── .github/
│   └── workflows/
│       └── tests.yml
├── .gitignore
├── LICENSE
├── pyproject.toml
├── requirements.txt
└── README.md
```

## Key metrics

### 1. Hemolysis time course
Plots the mean percentage hemolysis across post-convertase time points.

### 2. Hemolysis AUC
The trapezoidal area under the hemolysis-versus-time curve provides a simple sample-level summary of the functional signal.

### 3. Residual hemolysis
The 60-minute hemolysis value is retained as a late time-point indicator of residual convertase-associated activity.

## Interpretation

In this synthetic demonstration, a higher and more persistent hemolytic signal represents greater functional convertase stabilization.

This should **not** be interpreted as a validated diagnostic cutoff. C3NeF assays are heterogeneous, and results can depend on assay format, erythrocyte source, complement conditions, reference materials, and other technical factors.

## Scientific background

C3NeF targets/stabilizes the alternative-pathway C3 convertase and can prolong complement activation. Hemolytic assays using C3b-bearing erythrocytes have historically been used to assess this functional activity.

Relevant literature:

1. Chabannes M, Frémeaux-Bacchi V, Chauvet S. Detection of C3 Nephritic Factor by Hemolytic Assay. *Methods Mol Biol.* 2021;2227:147-158.
2. Vandenheuvel B, et al. Overactivity of Alternative Pathway Convertases in Patients With Complement-Mediated Renal Diseases. *J Am Soc Nephrol.* 2018.
3. Rother U. A new screening test for C3 nephritis factor based on a stable cell bound convertase on sheep erythrocytes. *J Immunol Methods.* 1982;51:101-107.
4. Skattum L. Analysis of C3 Nephritic Factors by ELISA. *Methods Mol Biol.* 2019;1901:177-182.

## Installation

```bash
git clone https://github.com/YOUR_USERNAME/c3nef-functional-assay.git
cd c3nef-functional-assay
pip install -r requirements.txt
```

## Run the analysis

```bash
python src/run_analysis.py
```

## Run tests

```bash
pytest
```

## Portfolio relevance

This project demonstrates practical experience with:

**Immunology → Complement biology → Functional assays → Quantitative analysis → Python → Data visualization → Reproducible research**

It is particularly relevant to biomedical research involving **complement dysregulation, C3 glomerulopathy, nephritic factors, renal immunopathology, and functional immunology assays**.
