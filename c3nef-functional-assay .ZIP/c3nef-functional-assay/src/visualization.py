from pathlib import Path
import matplotlib.pyplot as plt
import pandas as pd

def plot_time_course(df, output):
    summary = (
        df.groupby(["group","time_min"])["hemolysis_percent"]
        .agg(["mean","std"]).reset_index()
    )
    plt.figure(figsize=(8,5))
    for group, g in summary.groupby("group"):
        plt.errorbar(g["time_min"], g["mean"], yerr=g["std"],
                     marker="o", capsize=3, label=group)
    plt.xlabel("Convertase decay time (min)")
    plt.ylabel("Hemolysis (%)")
    plt.title("C3NeF Functional Assay: Hemolysis Over Time")
    plt.legend()
    plt.tight_layout()
    plt.savefig(output, dpi=300)
    plt.close()

def plot_auc(auc_df, output):
    plt.figure(figsize=(7,5))
    groups = [g for g in ["Negative","Positive"] if g in auc_df["group"].unique()]
    vals = [auc_df.loc[auc_df.group==g, "hemolysis_auc"] for g in groups]
    plt.boxplot(vals, labels=groups, showmeans=True)
    plt.ylabel("Hemolysis AUC (% × min)")
    plt.title("Sample-Level C3NeF Functional Signal")
    plt.tight_layout()
    plt.savefig(output, dpi=300)
    plt.close()

def plot_residual(auc_df, output):
    plt.figure(figsize=(7,5))
    groups = [g for g in ["Negative","Positive"] if g in auc_df["group"].unique()]
    vals = [auc_df.loc[auc_df.group==g, "residual_hemolysis_60min"] for g in groups]
    plt.boxplot(vals, labels=groups, showmeans=True)
    plt.ylabel("Residual hemolysis at 60 min (%)")
    plt.title("Residual Convertase-Associated Hemolysis")
    plt.tight_layout()
    plt.savefig(output, dpi=300)
    plt.close()
